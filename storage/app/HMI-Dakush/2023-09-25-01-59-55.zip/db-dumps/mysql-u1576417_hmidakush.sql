
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `berita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `berita` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `kategori_berita_id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal_rilis` date NOT NULL,
  `deskripsi` longtext NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `berita_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `berita` WRITE;
/*!40000 ALTER TABLE `berita` DISABLE KEYS */;
INSERT INTO `berita` VALUES (2,6,1,'HMI Komisariat Dakwah-Usuludin menyoroti mentalitas pragmatis mahasiswa','2023-08-03','<p>Menanggapi tahun ajaran baru di dunia akademik HMI komisariat Dakwah-Ushuluddin sebagai organsasi mahsiswa eksternal kampus mencoba mengkritisi keadaan sosiologi dan antropologi mahasiswa. HMI komisariat dakwah Ushuluddin mengadakan kajian yang bertemakan “Relevansi organisasi kemahasiswaan di tengah mentalitas pragmatisme mahasiswa” dalam kajian yang berjudul BINDER HMI (Bincang Kader HMI) kajian tersebut kader HMI Komisariat Dakwah-Ushuluddin mengupas tuntas menggunakan berbagai perspektif.</p><p>Dalam kajian tersebut &nbsp;Arya Lukmansyah selaku kepala bidang PPPA (Penelitian, Pengembangan Anggota, dan Pembinaan Anggota) &nbsp;HMI Komisariat Dakwah-Ushuluddin menjadi pemateri. Point yang disampaikan Arya dalam kajian tersebut adalah “pentingnya organisasi dalam melatih soft skill mahasiswa untuk mempersiapkan diri ketika lulus dari bangku kuliah, entah kita akan terjun dimasyarakat, dunia kerja dan menjalani hidup karena pendidikan karakter yang didapatkan dalam organisasi belum tentu didapatkan di bangku perkuliahan.” Sekalipun Arya menjadi pemateri tetapi dalam kajian tersebut menggunakan metode dialog interaktif yang memberikan keleluasaan terhadap seluruh peserta yang mengikuti kegiatan tersebut.</p><p>M Rokib selaku ketua Umum UKM KPN IAIN Kudus dan salah satu peserta juga sangat mengapresiasi kegiatan ini “bukan hanya dalam tubuh organisasi mahasiswa eksternal saja yang merasakan dampak akibat mentalitas pragmatis mahasiswa hari ini, tetapi organisasi intra kampus juga merasakan hal yang sama dimana hal tersebut saya rasakan semenjak awal masuk organisasi kampus sampai sekarang yang memiliki penurunan minat mahasiswa”</p><p>Kegiatan BINDER HMI dilaksanakan di Sekretariat HMI Komisariat Dakwah-Ushuluddin pada MInggu, 30 juli 2023 dengan sistem Blended (dicampur) offline dan online melalui Google Met, sebanyak 25 peserta turut berpartisipasi dalam kegiatan ini.Sejalan dengan hal tersebut M Iqbal Dzulkarnain selaku Formateur &nbsp;HMI Komisariat Dakwah-Ushuluddin memberikan keterangan kepada kita saat diwawancarai memberikan alasan kenapa mengadakan kegiatan ini “ HMI Komisariat Dakwah-Ushuluddin selaku organisasi eksternal mahasiswa ingin menjadi probelm solving terhadap problematika yang terjadi kita sebagai organisasi mhasiswa harus adaptif terhadap perkembangan zaman”</p><p>Bimo Widjianarko selaku moderartor juga mengharapkan kegiatan ini bukan hanya sekdar menjadi agenda formalitas “selesai kajian ini kita wajib memiliki kesadaran untuk memberikan pemahaman terhadap mahasiswa dan menjadi roll model bahwasanya organisasi memberikan dmpak positif untuk menjalani hidup dan mentalitas pragmatis merupakan suatu hal yang harus segera ditinggalkan karena membirkan dampak malas terhadap manusia”</p>','foto/berita/1691045741-IMG_20230730_193733_032.jpg','hmi-komisariat-dakwah-usuludin-menyoroti-mentalitas-pragmatis-mahasiswa','2023-08-02 23:55:42','2023-08-15 00:12:01'),(3,6,1,'Tiga Komisariat HMI Cabang Kudus berkomitmen menyelesaikan sengketa lahan di Desa Kelaling','2023-08-06','<p>Melalui tiga komisariat di bawah naungan HMI cabang Kudus mengadakan konsolidasi tentang <i>perampasan tanah warga Desa Kelaling secara sepihak untuk membangun Sentra Industri Hasil Tembakau.</i> Toriq Syihab selaku Pengurus HMI Cabang Kudus juga memberikan keterangan “Kegiatan hari ini merupakan langkah awal perjuangan kader-kader HMI Cabang Kudus untuk andil peran dalam menyelesaikan konflik sengketa lahan.”</p><p>Kegiatan konsolidasi kali ini dilaksanakan pada hari Sabtu 05/082023 pukul 21.00 WIB sampai 23.00 WIB bertempat di sekretariat HMI cabang Kudus, Desa. Karangbener Gg. 19 rt.01/rw.08, Kec. Bae, Kab. Kudus (59327).&nbsp;</p><p>Selain dihadiri perwakilan tiga komisariat senaungan HMI cabang Kudus yaitu HMI komisariat Tarbiyah, HMI komisariat Dakwah-Ushuluddin dan HMI Komisariat UMK, tidak kurang dari 10 peserta turut berpartisipasi dalam kegiatan tersebut.</p><p>Fajar Nugroho selaku perwakilan HMI komisariat Tarbiyah menjelaskan “Konsolidasi kegiatan kali ini merupakan bentuk komitmen mahasiswa sebagai kaum intelektual yang memiliki tanggung jawab sebagai sosial kontrol terhadap masyarakat, karena ada beberapa hal yang perlu kami kaji secara mendalam melalui beberapa metode sehingga kita dapat menemukan titik temu konflik yang terjadi antara masyarakat dan pemerintah.”&nbsp;</p><p>Sementara M Iqbal Dzulkarnain selaku formateur HMI komisariat Dakwah-Ushuluddin menyatakan “kami telah menyepakati dalam konsolidasi malam hari ini menghasilkan komitmen kader-kader HMI untuk memposisikan diri sebagai problem solving dalam kasus sengketa lahan antara masyarakat Desa Kelaling dan Pemerintah Daerah Kabupaten Kudus, dalam gerakan yang akan kita lakukan untuk kedepannya kita akan mencoba menggunakan pandangan yang objektif diantara kepentingan masyarakat dan kepentingan pemerintah dan di sini kita mempertegas diri sebagai fasilitator konflik antara keduanya.”</p><p>Konsolidasi yang dilakukan kader-kader HMI berjalan dengan penuh substansial karena banyak perspektif dan landasan akademik digunakan dalam merumuskan problem yang terjadi, pasca kegiatan konsolidasi yang diadakan pada malam hari ini kami akan segera melakukan audiensi terhadap kedua belah pihak yang pertama kita akan mengajak masyarakat desa kelaling dan yang selanjutnya kami akan menembusi pemerintah daerah melalui Disnaker Perinkom UMKM. Kami juga berharap agenda ini dapat diberikan kelancaran terhadap kedepanya sekalipun kita tau jalan yang akan kita tempuh akan sangat berat pungkas Wafna Jannata Ulya selaku Ketua Umum HMI Komisariat UMK.</p>','foto/berita/1691317076-WhatsApp Image 2023-08-06 at 10.30.13.jpeg','tiga-komisariat-hmi-cabang-kudus-berkomitmen-menyelesaikan-sengketa-lahan-di-desa-kelaling','2023-08-06 03:17:56','2023-08-15 00:12:40'),(4,6,1,'Audiensi HMI dan Masyarakat Desa Kelaling yang Terdampak pembangunan SIHT, Sri Mulyani: PEMDA Kabupaten Kudus Arogan Terhadap Masyarakat Kecil!!!','2023-08-08','<p>Audiensi yang dilaksanakan kader-kader HMI terhadap masyarakat Desa Kelaling yang menghadapi sengketa lahan dengan pemerintah daerah kabupaten Kudus merupakan tindak lanjut kajian yang dilaksanakan oleh tiga Komisariat HMI Cabang Kudus,&nbsp;</p><p>Ditujukan untuk menyerap aspirasi masyarakat yang terdampak pembangunan SIHT (Sentra Industri Hasil Tembakau), Kegiatan tersebut dilaksanakan pada hari Senin 7/08/2023 pada pukul 13. 00 WIB sampai 14.30 WIB yang bertempat di balai desa Kelaling Kecamatan Jekulo Kabupaten Kudus.</p><p>Kegiatan audiensi yang dilaksanakan oleh HMI dihadiri oleh pihak masyarakat yang terdampak pembangunan sentra industri hasil tembakau dan kader-kader HMI. “Sebenarnya target peserta terdapat perwakilan dari pejabat desa yang diwakili oleh Kepala Desa namun Pak Kades tidak dapat hadir karena masih ada agenda lain, kami sedikit menyayangkan sikap aparatur desa yang tidak berkenan untuk mewakili tetapi secara teknis Kami telah mengirimkan surat satu hari sebelumnya” keterangan yang diberikan oleh Agus selaku salah satu kader HMI yang menembusi beberapa pihak terkait.</p><p>&nbsp;Menurut pemaparan Sri Mulyani selaku masyarakat yang terdampak adanya pembangunan SIHT “pemerintah sangat arogan terhadap dirinya dan teman-teman pedagang yang menempati lahan yang akan digunakan untuk pembangunan SIHT, Karena ketika ada surat untuk pengosongan lapak yang di keluarkan oleh Disnaker Perinkom UMKM Kudus terhadap Sri Mulyani, dia langsung mengirim surat balasan terhadap Disnaker Perinkom UMKM Kudus yang di dalam surat tersebut Sri Mulyani dan kawan-kawannya ingin duduk bersama untuk mencari solusi yang terbaik dari kedua belah pihak tetapi balasan yang diterima langsung surat peringatan kedua dari sana Sri Mulyani menilai bahwasanya pihak Disnaker Perinkom UMKM tidak mau diajak untuk duduk bersama dan menyelesaikan masalah”&nbsp;</p><p>Sementara tanggapan &nbsp;M Iqbal Dzulkarnain selaku formateur HMI komisariat Dakwah-Ushuluddin \"sebenarnya yang menjadi problematika adalah komunikasi antara &nbsp;Disnaker Perinkom UMKM dan masyarakat yang terdampak yaitu, dalam sosialisasi yang diberikan oleh pihak Disnaker Perinkom UMKM terkait di situ tidak membahas secara utuh dalam &nbsp;menyelesaikan problematika yang terjadi. Sementara di sini HMI tetap berkomitmen menjadi fasilitator yang di mana kami akan menjadi penjembatan antara masyarakat yang terdampak pembangunan SIHT dan Disnaker Perinkom UMKM yang memiliki agenda untuk membangun SIHT.</p><p>Wafna Jannatul Ulya selaku Ketua Umum HMI komisariat UMK akan bertindak cepat dengan mencari solusi yang efektif dalam menyelsaikan sengketa lahan kali ini. “Pasca kegiatan audiensi bersama masyarakat desa kelaling yang terdampak pembangunan SIHT kami akan langsung mengadakan pendalaman kasus untuk merumuskan solusi yang efektif terhadap masyarakat terdampak”</p><p>\"Kami akan langsung menyurati secepatnya Disnaker Perinkom UMKM untuk mengadakan audiensi dan meminta klarifikasi terhadap keluhan-keluhan masyarakat yang terdampak rencana pembangunan SIHT\" pungkas Fajar Nugroho selaku perwakilan HMI komisariat Tarbiyah. Sampai berita ini diterbitkan masih belum ada informasi lebih lanjut baik dari pihak HMI sebagai fasilitator dan &nbsp;Disnaker Perinkom UMKM yang rencananya mengadakan Audiensi.</p>','foto/berita/1691447102-WhatsApp Image 2023-08-08 at 05.24.27.jpeg','audiensi-hmi-dan-masyarakat-desa-kelaling-yang-terdampak-pembangunan-siht-sri-mulyani-pemda-kabupaten-kudus-arogan-terhadap-masyarakat-kecil','2023-08-07 15:25:02','2023-08-07 15:35:45'),(5,6,1,'Audiensi HMI dan DISNAKER PERINKOM UMKM Tentang Sengketa Pembangunan SIHT Agus Juanto : Masyarakat Sadar  Tanah Tersebut Bukan Milik Mereka','2023-08-09','<p>Pasca melaksanakan audiensi bersama masyarakat Desa Kelaling yang terdampak pembangunan SIHT oleh DISNAKER PERINKOM UMKM pada tanggal 07/08/2023 sekarang giliran HMI mengajak audiensi DISNAKER PERINKOM UMKM untuk mengklarifikasi permasalahan sengketa lahan dan bangunan.</p><p>HMI dan &nbsp;DISNAKER PERINKOM UMKM melaksanakan audiensi di kantor &nbsp;DISNAKER PERINKOM UMKM Conge, Ngembalrejo lantai 2 pada tanggal 08/08/2023 Pukul 13.00 WIB samapai 14.30 WIB. Audiensi tersebut dihadiri oleh Agus Juanto selaku Kabid Hubungan Industrial dan Perselisihan Ketenagakerjaan yang mewakili Kepala DISNAKER PERINKOM UMKM Dra. Rini Kartika Hadi Rahmawati, MM yang sedang mngikuti rapat bersama Anggota DPRD Kabupaten Kudus. Sementara HMI Membawa delapan orang, yang tiga diantaranya perwakilan dari tiga komisariat HMI Cabang Kudus.</p><p>Agus Juanto memberikan jawaban atas isu sengketa yang berkembang di masyarakat bahwasanya DISNAKER PERINKOM UMKM sudah sesuai prosedural yang ada, dalam menjalankan SOP Administrasi pembangunan SIHT. Masyarakat sudah kita berikan dua kali sosialisasi dan 10 dari 12 masyarakat yang terdampak sudah bertanda tangan dan Rela untuk direlokasi mereka menyadari bahwasanya lahan yang mereka gunakan adalah lahan milik pemerintah dan mereka mendirikan itu secara ilegal, tetapi masih ada dua orang yang belum tanda tangan.</p><p>Sementara tanggapan &nbsp;M Iqbal Dzulkarnain selaku formateur HMI komisariat Dakwah-Ushuluddin Menegaskan bahwasanya HMI tidak memiliki kepentingan apapun terhadap sengketa lahan ini dan tidak ditunggangi oleh pihak manapun kegiatan ini merupakan bentuk dari tanggung jawab akademisi sebagai subjek sosial kontrol dan <i>Agent of Change</i> “Disini kami menegaskan untuk menjadi fasilitator antara konflik sengketa lahan masyarakat Desa kelaling yang terdampak pembangunan SIHT dan DISNAKER PERINKOM UMKM.”</p><p>HMI mengkritisi bahwasanya komunikasi yang dibangun oleh pihak DISNAKER PERINKOM UMKM dan masyarakat yang terdampak pembangunan SIHT sangat buruk. Selain itu, surat peringatan yang diberikan kepada masyarakat yang terdampak didalamnya mencantumkan Perda kabupaten Kudus Nomor 9 tahun 2022 dimana narasi yang digunakan dalam penggusuran dan pengosongan lahan yang ditempati oleh masyarakat kurang tepat. Karena perda itu digunakan untuk alokasi dana pengembangan UMKM bukan untuk penertiban dan penegakan keputusan Pemda. TegasFajar Nugroho selaku perwakilan HMI komisariat Tarbiyah.</p><p>kami memberikan solusi terhadap &nbsp;DISNAKER PERINKOM UMKM untuk audiensi bersama masyarakat Desa Kelaling yang terdampak pembangunan SIHT karena kemarin saat kita audiensi bersama masyarakat ada hal-hal kontradiktif dengan apa yang disampaikan oleh &nbsp;DISNAKER PERINKOM UMKM. Sebagai fasilitator kita tidak mau gegabah untuk langsung menyimpulkan sengketa lahan kali ini untuk mencapai kebenaran yang objektif dari kedua belah pihak maka audiensi adalah jalan yang paling efektif ditempuh yang dihadiri kedua belah pihak dan kita menjadi fasilitator, selain itu kami menuntut untuk segera melakukan audiensi dalam kurun waktu 3 kali 24 jam sejak audiensi ini dilaksanakan. Pungkas Wafna Jannatul Ulya selaku Ketua Umum HMI komisariat UMK.</p><p>Saya mewakili kepala dinas Sangat terbuka dan sangat mengapresiasi teman-teman HMI yang sudah mengajak audiensi dan memberikan solusi terhadap sengketa lahan pembangunan SIHT dan saya akan menyampaikan kepada kepala dinas terkait keinginan teman-teman HMI untuk mengadakan audiensi dari pihak DISNAKER PERINKOM UMK dan masyarakat Desa Kelaling yang terdampak pembangunan SIHT tetapi saya hari ini tidak bisa memutuskan bahwasanya hal tersebut dapat direalisasikan atau tidak karena saya di sini cuman mewakili dan saya tidak memiliki otoritas dalam pengambilan kebijakan tutup Agus Juanto sekaligus mengakhiri Audiensi kali ini.</p><p>&nbsp;</p>','foto/berita/1691563604-WhatsApp Image 2023-08-09 at 11.08.43.jpeg','audiensi-hmi-dan-disnaker-perinkom-umkm-tentang-sengketa-pembanunan-siht-agus-juanto-masyarakat-sadar-tanah-tersebut-bukan-milik-mereka','2023-08-08 23:46:44','2023-08-09 06:01:45'),(6,8,1,'Optimisme HMI Komisariat Dakwah-Ushuluddin menjadi contoh Organisasi lainya untuk lebih adaptif terhadap teknologi','2023-08-15','<p>Pelantikan Ketua dan Pengurus baru Himpunan Mahasiswa Islam (HMI) Cabang Kudus Komisariat Dakwah-Ushuluddin<strong>&nbsp;</strong>periode 2023-2024 diselenggarakan dengan launching website. &nbsp;Acara tersebut dilaksanakan pada minggu,13/08/2023 berjalan dengan lancar.</p><p>Pelantikan yang bertemakan” ‘’MENCIPTAKAN MAHASISWA BERKUALITAS ULUL ALBAB DAN SADAR AKAN HAK DAN KEWAJIBAN DALAM ORGANISASI,SERTA MAMPU MEMFORMULASIKAN IDE DAN GAGASANYA UNTUK MEWUJUDKANYA MASYARAKAT ADIL MAKMUR YANG DIRIDHOI ALLAH SWT’’ &nbsp;&nbsp;di&nbsp; Aula gedung DPRD Kabupaten Kudus ini &nbsp;dan dihadiri 20 orang lebih.</p><p>Dalam acara tersebut Fendy Zarmas Ariyanto Demisioner Ketua umum HMI Komisariat Dakwah-Ushuluddin Menyampaikan Sejarah singkat berdirinya HMI Komisariat Dakwah Ushuluddin, serta lika liku rintanagan yang dihadapinya selama ini “Dulu HMI Komisariat Dakwah-Ushuluddin dianggap sebelah mata, sekarang menjadii <i>rolle </i>model komisariat linya.” menurutnya salah satu kunci keberhasilanya yaitu dapat menghargai pendapat. Dia juga Mengutip dari kata kata Gus dur,Kalau ada perbedaan pendapat ,cukup sampai di kerongkongan,jangan dibawa sampai ke hati ,Berbeda pendapat itu wajar dalam berorganisasi ,sehaarusnya jika ada perbedaan pendapat dengan yang lain, bukanya malah memusuhi tapi mendampingi’’ujarnya.</p><p>Dalam sambutanya M Iqbal dzulkarnain selaku ketua umum baru priode 2023-2024 mengatakan pujian adalah racun dan kami tidak akan puas akan hal itu. ’’Terlepas dari pujian bahwa HMI Komisariat Dawah-Ushuluddin telah berkembang pesat serta menjadi salah satu contoh dari Komisariat lain, HMI Komisariat Dakwah-Ushuluddin tidak&nbsp; akan puas dan akan terus berbenah untuk menjadi tempat pengkaderan yang menciptakan mahasiswa berkualitas Ulul Albab yang sadar akan hak dan kewajibanya dalam berorganisasi, serta mampu menuangkan ide dan gagasannya untuk mewujudkan masyarakat adil makmur yang diridhoi Allah SWT sesuai tema hari ini”.</p><p>&nbsp;Ketua Umum Cabang Kudus, &nbsp;Wahyu Khoiri memuji perkembangan kekompakan komisariat dakwah ushuluddin dia juga berharap akan jauh lebih baik lagi di bawah kepemimpinan ketua umum yang baru. ’’Setiap pemimpin mempunyai gaya dan ide berbada dalam kepemmpinanya, begitu pula dengan Iqbal Dzulkarnain mempunyai gaya tersendiri dalam memimpin, saya berharap HMI Komisariat Dakwah ushuludin sebagai komisariat hebat naungan Cabang kudus akan menjadi lebih baik lagi dalam kepemimpinanya.”</p><p>Sampai sejauh ini organisasi kepemudaan ataupun kemahasiswaan minim yang melek terhadap teknologi khususnya di kabpaten Kudus. Hal ini merupakan sebuah terobosan baru yang positif jadi kedepanya HMI Komisariat Dakwah-Ushuluddin bukan hanya menjadi tauladan untuk HMI tapi lebih luasnya menjadi contoh yang baik untuk organisasi kemahasiswaan ataupun kepemudaan.</p><p>#HMI#YAKUSA</p>','foto/berita/1692082990-WhatsApp Image 2023-08-15 at 14.01.37.jpeg','optisme-hmi-komisariat-dakwah-ushuluddin-menjadi-contoh-organisasi-lainya-untu-lebih-adaptif-terhadap-teknologi','2023-08-15 00:03:10','2023-08-15 00:06:09'),(7,9,1,'HMI IKUT ANDIL PERAN DALAM MENGISI KEMERDEKAAN INDONESIA YANG KE 78 MELALUI PENGABDIAN MASYARAKAT DESA NGEMBALREJO','2023-08-18','<p>Antusias warga dukuh ngetuk Rt 08/01 Ngembalrejo, dalam mengikuti perlombaan untuk memperingati hari jadi Republik Indonesia ke - 78. &nbsp;Moment hari kemerdekaan Indonesia &nbsp;di sambut antusias oleh masyarakat, termasuk warga dukuh Ngetuk, dengan mengadakan berbagai jenis perlombaan dalam memeriahkan HUT RI Ke - 78, mulai dari perlombaan untuk kalangan anak - anak sampai &nbsp;kalangan orang dewasa. Perlombaan ini di selenggarakan di lapangan Ngetuk, yang diikuti dengan Gembira oleh peserta, yang mayoritas anak-anak dan ibu-ibu.</p><p>Bukan hanya perlombaan saja yang di adakan oleh panitia, melainkan ada banyak rangkaiaan acara untuk menyambut HUT RI Ke - 78. Rangkaian acara di mulai dari tanggal 16-20 Agustus 2023, pada tanggal 16 &nbsp;di isi dengan &nbsp;malam tirakatan, dilanjut tanggal 17 - 19 Agustus yang diisi dengan perlombaan, dan pada tanggal 20 &nbsp;merupakan acara puncak yang dimeriahkan <i>live music</i> dan ditutup pada tanggal 20 Agustus dengan jalan sehat bersama masyarakat Desa Ngetuk.&nbsp;</p><p>“Saya ucapkan banyak terimakasih kepada kawan-kawan HMI Cabang Kudus Komisariat Dakwah - Ushuluddin, yang telah ikut andil menjadi panitia dalam meramaikan kegiatan hari ini, &nbsp;dan saya mewakili warga mengucapkan banyak terimakasih untuk Joglo maqha yang telah mensuport acara ini.” Ujar Pak Wawan selaku Ketua Rt 08/01 Dukuh Ngetuk</p><p>Serly salsabella selaku ketua panitia pelaksana mengatakan, \" ini adalah momentum yang tepat karena HmI lahir dari unsur kondisi sosiologi masyarakat Indonesia &nbsp;dan ikut andil dalam acara kemsyarakatan adalah bentuk kongkrit terhadap pengabdian kepada masyarakat.&nbsp;</p><p>&nbsp;</p><p><br>&nbsp;</p>','foto/berita/1692370554-hut ri.jpg','hmi-ikut-andil-peran-dalam-mengisi-kemerdekaan-ndonesia-yang-ke-78-melalui-pengabdian-masyarakat-desa-ngembalrejo','2023-08-18 07:55:54','2023-08-18 07:57:34'),(8,6,1,'Ketua Umum HMI Komisariat Dakwah-Ushuluddin Diberi Rekomendasi Untuk jadi Bupati, Oleh Bupati Blora saat Tahlilan','2023-09-03','<p>Sabtu malam 02/09/2023 H. Arief Rohman, S.IP., M.Si selaku Bupati Blora periode 2021-2026 membersamai masyrakat Desa Sidomulyo Kecamatan Banjarejo Kabupaten Blora untuk melantunkan tahlil bersama dalam memperingati Haul Bu Mulyati yang merupakan ibu kandung dari Prof. Dr. H. Zaenal Mustakim, M.Ag selaku rektor UIN Gus Dur Pekalongan. Beliau beserta rombongan keluarga dengan khusyuk mengikuti rangkaian acara bersama masyarakat tanpa sekat yang membuat beliau membaur bersama masyarakat Desa Sidomulyo.&nbsp;</p><p>Di momen yang jarang sekali terjadi kebetulan M Iqbal Dzulkarnain selaku ketua umum HMI komisariat adalah Ushuluddin sedang melaksanakan KKN IKMB IAIN Kudus &nbsp;yang berada di Desa Sidomulyo juga ikut menghadiri acara haul Ibu Mulyati. “Saya ketika melihat dari posko rombongan yang dikawal oleh Polres Blora yang di mana Saya meyakini bahwasanya Pak Bupati akan menghadiri kegiatan haul Bu Mulyati, karena sebelum kegiatan haul kali ini sudah diberitahu oleh Pak Bambang selaku kepala dusun bakalan. Melihat sejarah pendidikan Pak Arif Rahman, S.IP., M.Si selaku bupati Blora ternyata 1 almamater di Pondok Pesantren Darul Ulum Peterongan Jombang. Namun. yang membedakan saya berada di pondok pesantren beliau kuliah di Universitas Darul ‘Ulum Jombang.”</p><p>Di kesempatan yang langka ini M Iqbal Dzulkarnain tidak menyia-nyiakan kesempatan yang ada Selesai acara tahlilan langsung menghampiri dan berkenalan kemudian meminta wejangan dari Pak Bupati Blora dalam kesempatan yang ada beliau menyampaikan “Terus semangat untuk meraih cita-cita di masa depan semoga kamu juga nanti bisa menjadi Bupati. Kebetulan istri saya juga dulu alumni MAN 2 Jombang yang merupakan tempat Muhammad Iqbal Dzulkarnain melalui masa sekolah aliyah di Pondok Pesantren Darul ‘Ulum.”</p><p>Sementara Pak Bambang selaku kepala dusun Bakalan memberikan keterangan “Pak Bupati memiliki kedekatan emosional dengan Prof. Dr. H. Zaenal Mustakim, M.Ag selaku Rektor UIN Gus Dur Pekalongan di mana dulu pernah menimba ilmu secara bersama. Jadi kedekatan emosional itu terbangun bukan ketika Pak Bupati mengenal Pak Zainal Mustaqim menjadi Rektor tetapi jauh sebelum Pak Zainal Mustaqim menjadi Rektor beliau sudah sangat akrab.”&nbsp;</p><p>Tidak kurang dari 100 orang desa Sidomulyo menghadiri haul Bu Mulyati. Acara tersebut berjalan dengan lancar tidak ada kendala apapun dan di sela-sela Pak Bupati membersamai masyarakat beliau langsung peka terhadap keluhan masyarakat desa Sidomulyo yang tidak lain perihal jalan yang masih tidak rata. Beliau menegaskan Untuk Mencoba berusaha agar pemerataan pembangunan sampai ke pelosok Desa Sidomulyo dapat merasakan hal yang sama khususnya pada infrastruktur.</p><p>“Saya merasa menjadi orang yang beruntung pada malam hari ini karena dapat bertemu dengan senior di Darul ‘Ulum yang menjadi pemimpin di Kabupaten Blora sekalipun hanya bertemu singkat ini merupakan momen yang tidak mungkin terulang dalam peristiwa lainnya. Saya juga sangat termotivasi dengan wejangan beliau untuk semakin percaya diri dalam realisasikan mimpi yang telah saya yakini sejak dulu meskipun kelak nantinya Jalan terjal sudah Menghadang tetapi itu bukan sebuah halangan yang mustahil untuk ditaklukan.” Tutur M Iqbal Zulkarnain selaku ketua umum HMI komisariat Dakwah-Ushuluddin.</p>','foto/berita/1693715736-WhatsApp Image 2023-09-03 at 11.09.29.jpeg','ketua-umum-hmi-komisariat-dakwah-ushuluddin-diberi-rekomendasi-untuk-jadi-bupati-oleh-bupati-blora-saat-tahlilan','2023-09-02 21:35:36','2023-09-02 21:40:04');
/*!40000 ALTER TABLE `berita` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `galeri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galeri` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `kategori_galeri_id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `galeri` WRITE;
/*!40000 ALTER TABLE `galeri` DISABLE KEYS */;
INSERT INTO `galeri` VALUES (2,2,1,'HMI Komisariat Dakwah-Ushuluddin Cabang Kudus berbagi Takjil','foto/galeri/1687254746-111.jpg','2023-06-20 02:52:26','2023-06-20 02:52:26'),(3,2,1,'HMI Komisariat Dakwah-Ushuluddin Cabang Kudus bakti sosial kepada kaum difabel','foto/galeri/1687254881-2222.jpg','2023-06-20 02:54:41','2023-06-20 02:54:41'),(4,2,2,'forum Bassic Training Lk-1','foto/galeri/1687254954-WhatsApp Image 2023-03-11 at 14.45.52 (2).jpeg','2023-06-20 02:55:54','2023-06-20 02:55:54'),(6,2,2,'penyerahan kepemanduan kordinator Sc kepada MOT','foto/galeri/1687255102-WhatsApp Image 2023-03-11 at 14.45.53.jpeg','2023-06-20 02:58:22','2023-06-20 02:58:22'),(7,2,3,'Demonstrasi tolak 3 periode presiden','foto/galeri/1687255305-IMG-20220412-WA0090.jpg','2023-06-20 03:01:45','2023-06-20 03:01:45'),(8,2,3,'Demonstrasi tolak 3 periode presiden','foto/galeri/1687255392-IMG-20220412-WA0094.jpg','2023-06-20 03:03:12','2023-06-20 03:03:12'),(9,2,2,'Pelatihan orasi HMI Komisariat Dakwah-Ushuluddin','foto/galeri/1687255453-IMG-20220118-WA0046.jpg','2023-06-20 03:04:13','2023-06-20 03:04:13'),(10,2,1,'HMI Komisariat Dakwah-Ushuluddin Cabang Kudus bakti sosial kepada kaum difabel','foto/galeri/1687255557-DSC_0883.JPG','2023-06-20 03:05:58','2023-06-20 03:05:58'),(11,2,2,'Diskusi kekerasan seksual terhadap wanita','foto/galeri/1687255636-IMG-20220420-WA0029.jpg','2023-06-20 03:07:16','2023-06-20 03:07:16'),(12,2,1,'Bakti sosial & Buka bersama anak yatim piatu','foto/galeri/1687255875-IMG-20230409-WA0038.jpg','2023-06-20 03:11:15','2023-06-20 03:11:15'),(13,2,1,'Pengabdian terhadap masyarakat','foto/galeri/1687255926-1111111.jpg','2023-06-20 03:12:06','2023-06-20 03:12:06'),(14,2,2,'Follow Up','foto/galeri/1687255988-WhatsApp Image 2023-03-12 at 10.54.56.jpeg','2023-06-20 03:13:08','2023-06-20 03:13:08'),(15,2,1,'berbagi takjil','foto/galeri/1687256023-111111.jpg','2023-06-20 03:13:43','2023-06-20 03:13:43'),(17,2,3,'Demonstrasi tolak kenaikan BBm','foto/galeri/1687256410-IMG-20220830-WA0037.jpg','2023-06-20 03:20:10','2023-06-20 03:20:10'),(18,2,3,'Demonstrasi tolak kenaikan BBm','foto/galeri/1687256497-IMG-20220830-WA0045.jpg','2023-06-20 03:21:37','2023-06-20 03:21:37'),(19,5,1,'penggalangan dana korban gempa cianjur','foto/galeri/1693210517-IMG-20221124-WA0026.jpg','2023-08-28 01:15:17','2023-08-28 01:15:17'),(20,5,2,'Uprading & Rapat Kerja','foto/galeri/1693210595-WhatsApp Image 2023-08-28 at 15.11.45.jpeg','2023-08-28 01:16:35','2023-08-28 01:16:35'),(21,5,1,'Audiensi HMI dan Masyarakat Desa Kelaling yang Terdampak pembangunan SIHT, Sri Mulyani: PEMDA Kabupaten Kudus Arogan Terhadap Masyarakat Kecil','foto/galeri/1693210643-WhatsApp Image 2023-08-08 at 05.24.27.jpeg','2023-08-28 01:17:23','2023-08-28 01:17:23'),(22,5,1,'HMI  mengabdi','foto/galeri/1693210701-WhatsApp Image 2023-08-18 at 19.13.12.jpeg','2023-08-28 01:18:21','2023-08-28 01:18:21'),(23,5,1,'Audiensi HMI dan DISNAKER PERINKOM UMKM Tentang Sengketa Pembanunan SIHT Agus Juanto : Masyarakat Sadar  Tanah Tersebut Bukan Milik Mereka','foto/galeri/1693210819-WhatsApp Image 2023-08-09 at 11.08.43.jpeg','2023-08-28 01:20:19','2023-08-28 01:20:19'),(24,5,2,'Diskusi Rutinan','foto/galeri/1693210906-WhatsApp Image 2023-08-06 at 10.30.13.jpeg','2023-08-28 01:21:46','2023-08-28 01:21:46'),(25,5,1,'Peduli Lingkungan','foto/galeri/1693210939-WhatsApp Image 2023-08-28 at 15.14.35.jpeg','2023-08-28 01:22:19','2023-08-28 01:22:19'),(26,5,1,'HMI Komisariat Dakwah-Ushuluddin Cabang Kudus bakti sosial kepada kaum difabel','foto/galeri/1693211453-IMG-20220422-WA0069.jpg','2023-08-28 01:30:53','2023-08-28 01:30:53'),(27,5,1,'Bakti sosial & Buka bersama anak yatim piatu','foto/galeri/1693211592-WhatsApp Image 2023-08-28 at 15.30.06.jpeg','2023-08-28 01:33:12','2023-08-28 01:33:12'),(28,5,2,'Pelatihan orasi HMI Komisariat Dakwah-Ushuluddin','foto/galeri/1693211644-WhatsApp Image 2023-08-28 at 15.30.05 (1).jpeg','2023-08-28 01:34:04','2023-08-28 01:34:04'),(29,5,2,'pelatihan Public Speaking','foto/galeri/1693211688-WhatsApp Image 2023-08-28 at 15.30.04.jpeg','2023-08-28 01:34:48','2023-08-28 01:34:48'),(30,5,2,'Diskusi Rutinan','foto/galeri/1693211741-WhatsApp Image 2023-08-28 at 15.30.04 (1).jpeg','2023-08-28 01:35:41','2023-08-28 01:35:41'),(31,5,1,'Pelatihan Teknik Persidangan','foto/galeri/1693211789-WhatsApp Image 2023-08-28 at 15.30.03.jpeg','2023-08-28 01:36:29','2023-08-28 01:36:29'),(32,5,2,'Follow Up','foto/galeri/1693211820-WhatsApp Image 2023-08-28 at 15.30.02.jpeg','2023-08-28 01:37:00','2023-08-28 01:37:00'),(33,5,2,'Rapat Anggota Komisariat','foto/galeri/1693211874-WhatsApp Image 2023-08-28 at 15.30.02 (2).jpeg','2023-08-28 01:37:54','2023-08-28 01:37:54'),(34,5,2,'Audiensi HMI bersama Pejabat Publik','foto/galeri/1693211913-WhatsApp Image 2023-08-28 at 15.30.02 (1).jpeg','2023-08-28 01:38:33','2023-08-28 01:38:33'),(36,5,2,'Audiensi HMI bersama Pejabat Publik','foto/galeri/1693212050-WhatsApp Image 2023-08-28 at 15.29.59 (1).jpeg','2023-08-28 01:40:50','2023-08-28 01:40:50'),(37,5,2,'Pelantikan pengurus','foto/galeri/1693212078-WhatsApp Image 2023-08-28 at 15.29.59.jpeg','2023-08-28 01:41:18','2023-08-28 01:41:18'),(38,5,1,'Audiensi HMI dan Masyarakat Desa Kelaling yang Terdampak pembangunan SIHT, Sri Mulyani: PEMDA Kabupaten Kudus Arogan Terhadap Masyarakat Kecil','foto/galeri/1693212102-WhatsApp Image 2023-08-28 at 15.30.00 (1).jpeg','2023-08-28 01:41:42','2023-08-28 01:41:42'),(39,5,2,'Makrab HMI','foto/galeri/1693212163-WhatsApp Image 2023-08-28 at 15.30.00.jpeg','2023-08-28 01:42:43','2023-08-28 01:42:43'),(40,5,1,'Bakti sosial bersama Difabel','foto/galeri/1693212235-WhatsApp Image 2023-08-28 at 15.30.01.jpeg','2023-08-28 01:43:55','2023-08-28 01:43:55'),(41,5,1,'Bakti sosial bersama Difabel','foto/galeri/1693212296-WhatsApp Image 2023-08-28 at 15.30.01 (1).jpeg','2023-08-28 01:44:56','2023-08-28 01:44:56');
/*!40000 ALTER TABLE `galeri` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kategori_berita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori_berita` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kategori_berita` WRITE;
/*!40000 ALTER TABLE `kategori_berita` DISABLE KEYS */;
INSERT INTO `kategori_berita` VALUES (1,'Kegiatan Organisasi',NULL,'2023-05-05 05:10:36'),(2,'Ekologi','2023-05-05 05:11:34','2023-05-05 05:11:34'),(3,'Buruh','2023-05-05 05:12:07','2023-05-05 05:12:07');
/*!40000 ALTER TABLE `kategori_berita` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kategori_galeri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori_galeri` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kategori_galeri` WRITE;
/*!40000 ALTER TABLE `kategori_galeri` DISABLE KEYS */;
INSERT INTO `kategori_galeri` VALUES (1,'Sosial & Kemasyarakatan',NULL,'2023-05-05 04:55:48'),(2,'Perkaderan','2023-05-05 04:56:42','2023-05-05 04:56:42'),(3,'Aksi Massa','2023-05-05 05:06:16','2023-05-05 05:06:16');
/*!40000 ALTER TABLE `kategori_galeri` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kategori_publikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori_publikasi` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kategori_publikasi` WRITE;
/*!40000 ALTER TABLE `kategori_publikasi` DISABLE KEYS */;
INSERT INTO `kategori_publikasi` VALUES (1,'Essai',NULL,'2023-05-05 05:06:56'),(2,'Hasil Kajian','2023-05-05 05:07:18','2023-05-05 05:07:18'),(3,'Puisi','2023-05-05 05:08:32','2023-05-05 05:08:32');
/*!40000 ALTER TABLE `kategori_publikasi` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kepengurusans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kepengurusans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `periode` varchar(255) NOT NULL,
  `konten` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kepengurusans` WRITE;
/*!40000 ALTER TABLE `kepengurusans` DISABLE KEYS */;
INSERT INTO `kepengurusans` VALUES (1,'2022/2023','judul',NULL,NULL);
/*!40000 ALTER TABLE `kepengurusans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `komentar_berita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `komentar_berita` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `berita_id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `komentar` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `komentar_berita` WRITE;
/*!40000 ALTER TABLE `komentar_berita` DISABLE KEYS */;
INSERT INTO `komentar_berita` VALUES (1,1,'Erik','erik@gmail.com','Butuh tindakan jangan hanya pendapat!!','2023-05-05 05:54:23','2023-05-05 05:54:23'),(2,3,'Bagus','info\'@kudus','Lanjutkan....','2023-08-06 04:03:15','2023-08-06 04:03:15'),(3,3,'Angga','angga321@gmail.com','Kalau masalah lahan ya langsung ke BPN...\r\nNgapain ke UMKM.\r\nMusprooooo','2023-08-06 19:05:09','2023-08-06 19:05:09'),(4,4,'Orang sehat','orangsehatindonesia@gmail.com','Gandeng LBH Aman... Somasi','2023-08-07 23:43:59','2023-08-07 23:43:59');
/*!40000 ALTER TABLE `komentar_berita` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `komentar_publikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `komentar_publikasi` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `publikasi_id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `komentar` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `komentar_publikasi` WRITE;
/*!40000 ALTER TABLE `komentar_publikasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `komentar_publikasi` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2023_04_21_120311_create_kategori_publikasis_table',1),(5,'2023_04_23_095816_create_publikasis_table',1),(6,'2023_04_28_120704_create_kategori_beritas_table',1),(7,'2023_04_28_120713_create_beritas_table',1),(8,'2023_04_28_134038_create_tentang_kamis_table',1),(9,'2023_04_28_134125_create_kategori_galeris_table',1),(10,'2023_04_28_134126_create_galeris_table',1),(11,'2023_05_05_121332_create_komentar_publikasis_table',2),(12,'2023_05_05_121446_create_komentar_beritas_table',2),(13,'2023_05_14_004421_create_kepengurusans_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `publikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publikasi` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `kategori_publikasi_id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal_rilis` date NOT NULL,
  `deskripsi` longtext NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `publikasi_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `publikasi` WRITE;
/*!40000 ALTER TABLE `publikasi` DISABLE KEYS */;
INSERT INTO `publikasi` VALUES (5,2,1,'Perilaku Politisi Menggunakan Politik Praktis Dalam Sistem kekuasaan Indonesia','2023-06-20','<p><a href=\"  https://drive.google.com/file/d/1BuDb1nUHKrgd4ubLosCb_CHw5q4ja2Nu/view?usp=drivesdk\">&nbsp; https://drive.google.com/file/d/1BuDb1nUHKrgd4ubLosCb_CHw5q4ja2Nu/view?usp=drivesdk</a></p>','foto/publikasi/1687257163-IMG_20230502_162122_087.jpg','perilaku-politisi-menggunakan-politik-praktis-dalam-sistem-kekaman-indonesia','2023-06-20 03:32:44','2023-06-20 03:36:29'),(7,1,1,'Mengubah Paradigma Industri Tekstil di Pekalongan: Menuju Produksi yang Ramah Lingkungan dan Berkelanjutan','2023-08-03','<p><a href=\"https://drive.google.com/file/d/1KhiT2GEoJLyTN8HmBj8w0rXCfsiteIyv/view?usp=drivesdk\">https://drive.google.com/file/d/1KhiT2GEoJLyTN8HmBj8w0rXCfsiteIyv/view?usp=drivesdk</a>&nbsp;</p>','foto/publikasi/1691053008-WhatsApp Image 2023-08-03 at 15.34.37.jpeg','mengubah-paradigma-industri-tekstil-di-pekalongan-menuju-produksi-yang-ramah-lingkungan-dan-berkelanjutan','2023-08-03 01:56:48','2023-08-03 02:01:41');
/*!40000 ALTER TABLE `publikasi` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tentang_kamis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tentang_kamis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tentang_kamis` WRITE;
/*!40000 ALTER TABLE `tentang_kamis` DISABLE KEYS */;
/*!40000 ALTER TABLE `tentang_kamis` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT 0,
  `gambar` varchar(255) NOT NULL DEFAULT 'foto/user/user.jpg',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'user','user@gmail.com',NULL,'$2y$10$Lpa1gORquhJ.d4f0lpLUduBO2LY7IZxs2OTBY9r13izE3cHAE7F/2',0,'foto/user/user.jpg',NULL,NULL,NULL),(2,'Admin','admin@gmail.com',NULL,'$2y$10$x8NvnB8ERdAED8zgQ2qQV.UfRsoFWFaizMw0NET7OBknrRd2bqvQi',1,'foto/user/user.jpg',NULL,NULL,NULL),(5,'M Iqbal Dzulkarnan','semaresenyum612@gmail.com',NULL,'$2y$10$gR50VWXGFLaHx/DY8709guvy.etmP2lkLDVVU09f.PYiGdR6jj1vW',0,'foto/user/1691376701-IMG_7164.JPG',NULL,'2023-08-06 19:51:43','2023-08-06 19:51:43'),(6,'Bimo Wijianarko','bimobim525@gmail.com',NULL,'$2y$10$gW1oE7hKy0AjkHMM3qW3iu/Q.e0LdXP1sSambl0NQqXmzO.Iou7A.',0,'foto/user/1691442726-WhatsApp Image 2023-08-08 at 04.11.36.jpeg',NULL,'2023-08-07 14:12:06','2023-08-07 14:12:06'),(8,'Irfan Solahudin A','irfanshollahuddin5@gmail.com',NULL,'$2y$10$bAKwJiZ9M110I27q6eDj8u3BYH9eQLg6tpboSuZyZp0Ie/Kwf7K2i',0,'foto/user/1692014888-WhatsApp Image 2023-08-14 at 19.06.38.jpeg',NULL,'2023-08-14 05:08:08','2023-08-14 05:08:08'),(9,'Muhmmad Arya Luqmansyah','aryaluqmansyah583@gmail.com',NULL,'$2y$10$BsJgBKrkA3NyOh5QGcq.GO4iHpoK1Wk9Ifd9rGAZS7q.EiFi9RuQi',0,'foto/user/1692366297-2906c36a-d4a0-49b0-871b-c0b0f9d0150a.jpg',NULL,'2023-08-18 06:44:57','2023-08-18 06:44:57'),(10,'M Rokib','ccoc27596@gmail.com',NULL,'$2y$10$vqZfMwg6yxI/dyhowgJdwu9sO16i5QNMGWECPQAywE0g8VNWjFEf2',0,'foto/user/1692938337-WhatsApp Image 2023-08-25 at 11.37.56.jpeg',NULL,'2023-08-24 21:38:57','2023-08-24 21:38:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

